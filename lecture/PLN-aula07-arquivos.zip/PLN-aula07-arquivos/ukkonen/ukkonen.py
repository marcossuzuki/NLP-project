'''Compute edit distances using Ukkonen, 1985.

This module computes edit distances (also called Levenshtein distance)
based on the article "Algorithms for Approximate String Matching"
(Ukkonen, 1985).

The 2 functions that should be imported from this module are:

+ is_edit_le(s1, s2, le) :: tests if the edit distance is less than or
equal to le

+ edit_distance(s1, s2) :: the edit distance between the strings s1
and s2

The most useful function is `is_edit_le' because it is the one that
could potentially save CPU cycles if you are only interested on limits
of distances.

`is_edit_le' needs time O(le * min(m, n)).

'''

from decimal import Decimal
from itertools import count

_inf = Decimal('Inf')

class _Fkp (dict):
    '''Fkp table that extends dict.

    Fkp should be used only with 2-tuples and when there is a missing
    key, the following is returned:

    Fkp[k, p] = |k| - 1, if p = |k| - 1 and k < 0;

                -1, if p = |k| - 1;

                -inf, otherwise.

    '''
    def __missing__(self, kp):
        k, p = kp
        if p == abs(k) - 1:
            self[kp] = abs(k) - 1 if k < 0 else -1
        else:
            self[kp] = -_inf
        return self[kp]

def _fill_f_kp(k, p, f_kp, s1, s2):
    '''Fill f_kp according to algorithm 8 from Ukkonen, 1985.'''
    t = max(f_kp[k, p-1] + 1,
            f_kp[k-1, p-1],
            f_kp[k+1, p-1] + 1)
    while t < len(s1) and t + k < len(s2) and s1[t] == s2[t+k]:
        t += 1
    f_kp[k, p] = t

def is_edit_le(s1, s2, le):
    '''Return the edit distance if <= le; return le+1 otherwise.

    The edit distance between the strings s1 and s2 is the minimum
    number of edit operations (insertion, deletion, change) to turn s1
    into s2.

    This procedure implements algorithm 11 of article "Algorithms for
    Approximate String Matching" (Ukkonen, 1985).

    For example, if you want to test if the edit distance between s1
    and s2 are at most 2, call `is_edit_le' with le = 2.  If it
    returns anything larger than 2, the edit distance is larger than
    2, but you don't know how larger it is.

    '''
    m = len(s1)
    n = len(s2)
    p = -1
    r = p - min(m, n)
    f_kp = _Fkp()
    while (n-m, p) not in f_kp or f_kp[n-m, p] != m:
        p += 1
        if p > le:
            # The number of edit operations is larger than the limit
            # le
            return p
        r += 1
        if r <= 0:
            for k in range(-p, p+1):
                _fill_f_kp(k, p, f_kp, s1, s2)
        else:
            for k in range(max(-m, -p), -r+1):
                _fill_f_kp(k, p, f_kp, s1, s2)
            for k in range (r, min(n, p) + 1):
                _fill_f_kp(k, p, f_kp, s1, s2)
    return p

def edit_distance(s1, s2):
    '''Return the edit distance between s1 and s2.

    The edit distance between 2 strings is the number of edit
    operations (insert, deletion, changes) to turn s1 into s2.

    '''
    # The edit distance is computed by testing the limit of the
    # distance with the sequence <0, 1, 2, 3, ...>.  The testing stops
    # as soon as the edit distance matches the limit.
    for i in count():
        if is_edit_le(s1, s2, i) == i:
            return i
#deduplicação de palavras
if __name__ == '__main__':
    import unittest
    class TestEditLimit(unittest.TestCase):
        def test_limit(self):
            self.assertEqual(is_edit_le('', '', 0), 0)
            self.assertEqual(is_edit_le('a', '', 1), 1)
            self.assertEqual(is_edit_le('', 'a', 1), 1)
            self.assertEqual(is_edit_le('a', 'a', 1), 0)
            self.assertEqual(is_edit_le('a', 'b', 1), 1)
            self.assertEqual(is_edit_le('a', 'b', 0), 1)
            self.assertEqual(is_edit_le('foo', 'bar', 3), 3)
            self.assertEqual(is_edit_le('foo', 'bar', 2), 3)
            self.assertEqual(is_edit_le('foo', 'bar', 1), 2)
            self.assertEqual(is_edit_le('foo', 'bar', 0), 1)
            self.assertEqual(is_edit_le('foo', 'bar', 4), 3)
            self.assertEqual(is_edit_le('foo', 'bar', 5), 3)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 0), 1)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 1), 2)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 2), 3)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 3), 3)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 4), 3)
            self.assertEqual(is_edit_le('yxxzy', 'xyxzyz', 4), 3)
            self.assertEqual(is_edit_le('xyxzyz', 'yxxzy', 0), 1)
            self.assertEqual(is_edit_le('xyxzyz', 'yxxzy', 1), 2)
            self.assertEqual(is_edit_le('xyxzyz', 'yxxzy', 2), 3)
            self.assertEqual(is_edit_le('xyxzyz', 'yxxzy', 3), 3)
            self.assertEqual(is_edit_le('xyxzyz', 'yxxzy', 4), 3)
        def test_distance(self):
            self.assertEqual(edit_distance('', ''), 0)
            self.assertEqual(edit_distance('a', ''), 1)
            self.assertEqual(edit_distance('', 'a'), 1)
            self.assertEqual(edit_distance('foo', 'bar'), 3)
            self.assertEqual(edit_distance('bar', 'foo'), 3)
            self.assertEqual(edit_distance('yxxzy', 'xyxzyz'), 3)
            self.assertEqual(edit_distance('xyxzyz', 'yxxzy'), 3)
    unittest.main()
