#!/usr/bin/env python 
# encoding: utf-8

import sys

def hamming(s1, s2):
    if len(s1) == len(s2):
        cont = 0
        for i in range(0, len(s2)):
            if s1[i]!=s2[i]:
                cont = cont + 1 
        return cont
    else:
        return -1
 

if __name__ == "__main__":
    
    print( hamming("PLN", "PNL") )
    print( hamming("UFABC", "UFRJ")  )
    print( hamming("UFABC", "UFRRJ") )
    



