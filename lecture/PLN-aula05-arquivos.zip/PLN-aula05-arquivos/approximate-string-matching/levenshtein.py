#!/usr/bin/env python 
# encoding: utf-8
import sys

def Levenshtein(s1,s2):
    if len(s1) > len(s2):
        #s1,s2 = s2,s1
        temp = s1
        s1 = s2
        s2 = temp
    
    #caso base
    if len(s1)==0 or len(s2)==0:
        if len(s1)>len(s2):
            return len(s1)
        else:
            return len(s2)

    #def. de custo
    if s1[-1] == s2[-1]:
        custo = 0
    else:
        custo = 1

    # determina o melhor caminho na comparacao
    primeiroTermo = Levenshtein(s1[:-1],s2) + 1
    segundoTermo  = Levenshtein(s1,s2[:-1]) + 1
    terceiroTermo = Levenshtein(s1[:-1],s2[:-1]) + custo
    
    return min( primeiroTermo, segundoTermo, terceiroTermo)

if __name__ == "__main__":
    frase1= "CASA"
    frase2= "PATA"
    print( Levenshtein(frase1, frase2) )

    frase1= "Luiz Paulo"
    frase2= "Luis Paulo"
    print( Levenshtein(frase1, frase2) )

    frase1= "Luiz Paulo Roberto Cozta"
    frase2= "Luis Paulo Roberto Cotia"
    print( Levenshtein(frase1, frase2) )
       

