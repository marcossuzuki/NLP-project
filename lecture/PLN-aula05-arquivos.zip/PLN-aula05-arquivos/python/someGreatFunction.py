def someGreatFunction(arr):
    if len(arr) <= 1:
        return arr

    pivot  = arr[-1]

    left   = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right  = [x for x in arr if x > pivot]
 
    return someGreatFunction(left) + middle + someGreatFunction(right)


print( someGreatFunction([3, 6, 8, 10, 1, 2, 1]) )
print( someGreatFunction([11, 22, 33, 99, 88, 77, 44, 66, 77]) )

