class Animal(object):
    def __init__(self, species, age): # Constructor `a = Animal(‘bird’, 10)`
        self.species = species        # Refer to instance with `self`
        self.age = age                # All instance variables are public

    def isPerson(self):               # Invoked with `a.isPerson()`
        return self.species == “Homo Sapiens”

    def ageOneYear(self):
        self.age += 1


class Dog(Animal):                    # Inherits Animal’s methods
    def ageOneYear(self):             # Override for dog years
        self.age += 7

